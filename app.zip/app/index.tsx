import { Text, View, TextInput } from "react-native";

export default function(){
    <View>
        <Text>Aberura de chamado</Text>

        <Text>Titulo</Text>
        <Text>Descrição</Text>
        <Text>Status</Text>
        <Text>Prioridade</Text>
        
    </View>
};