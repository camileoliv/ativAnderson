import React, { useState} from "react";
import { StyleSheet, Text, View, Button, TouchableOpacity } from "react-native";
import {styles} from './styles';

export default function Home(){
    return (
        <View style={styles.container2}>
            <Text>
                Acompanhador de chamados
            </Text>
            <TouchableOpacity>
                <Button title="Iniciar" />
            </TouchableOpacity>
        </View>
    );
}