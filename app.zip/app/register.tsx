import { Text, View, TextInput } from "react-native";

export default function register(){
    <View>
        <Text>
            Cadastro
        </Text>

        <Text>Nome</Text>
        <TextInput placeholder="Primeiro nome"/>
        <Text>Sobrenome</Text>
        <TextInput placeholder="Segundo nome"/>
        <Text>E-mail</Text>
        <TextInput placeholder="Segundo nome"/>
        <Text>Senha</Text>
        <TextInput secureTextEntry={true} placeholder="Senha básica"/>
        {/* <Text>Você é cliente ou técnico?</Text> pedir cargo  */}
    </View>
};