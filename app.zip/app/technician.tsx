import { Text, View, TextInput } from "react-native";

export default function technician(){
    return (
        <View>

        <Text>Titulo</Text>
        <Text>Descrição</Text>
        <Text>Status</Text>
        <Text>Prioridade</Text>
        <Text>Data criação</Text>
        <Text>Data conclusão</Text>
        <Text>Categoria</Text>
        
        </View>
    );
};